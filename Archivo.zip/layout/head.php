<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VM Salud - Laboratorio</title>
<meta property="og:title" content="VM Salud - Laboratorio">
<meta property="og:type" content="article">
<meta property="og:url" content=" https://vmsalud.neuronadigital.tech/">
<meta property="og:image" content="https://vmsalud.neuronadigital.tech/assets/images/vm-salud.png">
<meta property="og:description" content="Estamos comprometidos con las personas y con su salud, por ello mantenemos las mejores medidas de calidad en nuestros servicios.">
<link rel="icon" href="assets/images/favicon.png">
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/aos.css">
<link rel="stylesheet" href="assets/css/main.css">